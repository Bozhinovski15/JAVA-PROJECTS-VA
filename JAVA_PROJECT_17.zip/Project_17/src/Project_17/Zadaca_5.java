package Project_17;

import java.util.Scanner;

public class Zadaca_5 {

	public static void main(String[] args) {
		Scanner tastatura = new Scanner(System.in);
		int a,b,c,d;
		int k=1;
		System.out.println("Vnesi vrednost za A: ");
		a=tastatura.nextInt();
		System.out.println("Vnesi vrednost za B: ");
		b=tastatura.nextInt();
		System.out.println("Vnesi vrednost za C: ");
		c=tastatura.nextInt();
		if(a<=5 && b<(a-c))
		{
			System.out.println(k);
		}
		else if(c == 0)
		{
			d=0;
			System.out.println(d);
		}
	}

}
