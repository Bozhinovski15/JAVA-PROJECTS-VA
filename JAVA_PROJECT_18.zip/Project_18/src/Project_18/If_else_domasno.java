package Project_18;

public class If_else_domasno {

	public static void main(String[] args) {
		int age = 25;
		if(age > 0)
		{
			if( age > 16 )
			{
				System.out.println("Welcome!");
			}
			else
			{
				System.out.println("Too Young !");
			}
			
		}
		else 
		{
			System.out.println("Error");
		}
		// Outputs "Welcome!"

	}

}
