package Project_10_Domasno;
import java.util.Scanner;

public class Kod {

    public static void main(String[] args) {
        String i_p_registracija; 
        String i_p_korisnicko;
        int cin;
        int password_registracija; 
        int password_login; 
        System.out.println("| VA SECURITY SYSTEM |");
        Scanner scanner = new Scanner(System.in);
        System.out.println("| ---- REGISTRACIJA ---- |");
        System.out.print("| Vnesi korisnicko ime :  ");
        i_p_registracija = scanner.nextLine();
        System.out.print("| Vnesi password od brojki: ");
        String password_registracijaString = scanner.nextLine(); 
        password_registracija = Integer.parseInt(password_registracijaString);
        System.out.println("Vnesete go vasiot cin : ");
        System.out.println("| Pitomec [0] ");
        System.out.println("| Potporucnik [1] ");
        System.out.println("| Porucnik [2] ");
        System.out.println("| Kapetan [3] ");
        System.out.println("| Major [4] ");
        System.out.println("| Potpolkovnik [5] ");
        System.out.println("| Polkovnik [6] ");
        cin = scanner.nextInt();
        scanner.nextLine();
        System.out.println("|------------------------------|");
        //
        System.out.println("| Korisnikot e uspesno kreiran |");
        //
        System.out.println("|------------------------------|");
        System.out.println("| VA SECURITY SYSTEM |");
        System.out.println("| ---- LOGIN ---- |");
        System.out.print("| Vnesi korisnicko ime :  ");
        i_p_korisnicko= scanner.nextLine();
        System.out.print("| Vnesi password od brojki: ");
        String password_loginString = scanner.nextLine();
        password_login = Integer.parseInt(password_loginString);
        if (i_p_registracija.equals(i_p_korisnicko) && password_registracija == password_login) {
            System.out.print("| Uspesno vlegovte vo sistemot. Dobredojdovte " + i_p_registracija);
            System.out.println(" ! ");
            if (cin == 0) {
                System.out.print("| Najaveni ste pod cinot: PITOMEC");
            } else if (cin == 1) {
                System.out.print("| Najaveni ste pod cinot: POTPORUCNIK");
            } else if (cin == 2) {
                System.out.print("| Najaveni ste pod cinot: PORUCNIK");
            } else if (cin == 3) {
                System.out.print("| Najaveni ste pod cinot: KAPETAN");
            } else if (cin == 4) {
                System.out.print("| Najaveni ste pod cinot: MAJOR");
            } else if (cin == 5) {
                System.out.print("| Najaveni ste pod cinot: POTPOLKOVNIK");
            } else if (cin == 6) {
                System.out.print("| Najaveni ste pod cinot: POLKOVNIK");
            } else {
                System.out.print("| Vneseni se pogresnite podatoci! |");
            }
        } else {
            System.out.print("| Vneseni se pogresnite podatoci! ");
        }
    }
}
