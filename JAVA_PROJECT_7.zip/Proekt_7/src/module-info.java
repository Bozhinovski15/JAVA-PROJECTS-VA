/**
 * 
 */
/**
 * 
 */
module Proekt_7 {
}